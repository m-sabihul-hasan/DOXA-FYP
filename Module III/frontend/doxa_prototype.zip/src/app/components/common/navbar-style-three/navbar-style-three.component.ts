import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-style-three',
  templateUrl: './navbar-style-three.component.html',
  styleUrls: ['./navbar-style-three.component.scss']
})
export class NavbarStyleThreeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
