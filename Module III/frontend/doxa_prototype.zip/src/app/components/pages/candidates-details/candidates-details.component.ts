import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidates-details',
  templateUrl: './candidates-details.component.html',
  styleUrls: ['./candidates-details.component.scss']
})
export class CandidatesDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
