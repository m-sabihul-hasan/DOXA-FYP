import { Component, OnInit } from '@angular/core';
import { GlobalVariablesService } from 'src/app/global-variables.service';

@Component({
  selector: 'app-resume-details',
  templateUrl: './resume-details.component.html',
  styleUrls: ['./resume-details.component.scss']
})
export class ResumeDetailsComponent implements OnInit {

  experience = 0;

  qualification = "";

  constructor(public global_vars: GlobalVariablesService) { }

  ngOnInit(): void 
  {
    this.calculate_experience();

    this.set_qualification();
  }

  calculate_experience()
  {
    for(let i = 0; i < this.global_vars.work_experience.length; i++)
    {
      let start: number = +this.global_vars.work_experience[i].Starting_Year;
      let end: number = +this.global_vars.work_experience[i].Ending_Year; 

      if (start == NaN)
        start = 0;
      
      if (end == NaN)
        end = 0;

      this.experience += (end- start);
    }
  }


  set_qualification()
  {
    let qualifications = [];
    for(let i = 0; i < this.global_vars.education.length; i++)
    {
      qualifications.push( this.global_vars.education[i].Title );
    }

    this.qualification = qualifications.join(", ");
  }

}
