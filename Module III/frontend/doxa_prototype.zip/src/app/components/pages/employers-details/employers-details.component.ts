import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employers-details',
  templateUrl: './employers-details.component.html',
  styleUrls: ['./employers-details.component.scss']
})
export class EmployersDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
