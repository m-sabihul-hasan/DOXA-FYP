import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favourite-jobs',
  templateUrl: './favourite-jobs.component.html',
  styleUrls: ['./favourite-jobs.component.scss']
})
export class FavouriteJobsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
