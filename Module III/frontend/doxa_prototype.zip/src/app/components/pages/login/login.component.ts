import { Component, OnInit } from '@angular/core';
import { RoutingService } from 'src/app/routing.service';
import { SocketService } from 'src/app/socket.service';
import { GlobalVariablesService } from 'src/app/global-variables.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private routing_service: RoutingService, private socket_service: SocketService, public global_vars: GlobalVariablesService) { }

  ngOnInit(): void 
  {
    console.log(this.global_vars.user_data);
    if (this.global_vars.user_data_retrieved)
      window.location.reload();
  }

  to_register()
  {
    this.routing_service.login_to_register();
  }

  login(data)
  {
    this.global_vars.hide_error = true;

    if (this.socket_service.validate_input(data))
    {
      this.socket_service.login(data);
    }
    else
    {
      this.global_vars.error = "* Required fields cannot be empty.";
      this.global_vars.hide_error = false;
    }
  }
}
