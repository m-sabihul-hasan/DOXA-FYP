import { Injectable } from '@angular/core';
import { Socket } from 'ngx-socket-io';

import { GlobalVariablesService } from './global-variables.service';
import { RoutingService } from './routing.service';


@Injectable({
  providedIn: 'root'
})
export class SocketService {

  constructor(private socket: Socket, private global_vars: GlobalVariablesService, private routing_service: RoutingService) 
  {
    this.on_register_reply().subscribe((data: any) => {
      if (data.account_created == false)
      {
        global_vars.error = `${data.duplicate.join(", ")} already in use.`
        global_vars.hide_error = false;
      }
      else
      {
        this.global_vars.user_data = data;
        this.global_vars.user_data_retrieved = true;
        this.routing_service.register_to_dashboard();
      }
    });
  
    this.on_login_reply().subscribe((data: any) => {
      if (data != null)
      {
        this.global_vars.user_data = data;
        this.global_vars.user_data_retrieved = true;
        this.routing_service.login_to_dashboard();
      }
      else
      {
        global_vars.error = "Invalid email/password."
        global_vars.hide_error = false;
      }
    });
  


  
    this.on_dashboard_info_reply().subscribe((data: any) => {
      this.dashboard_reply_job(data);
    });
  
    



    this.on_updated_user_data().subscribe((data: any) => {
      this.global_vars.updated_user_data_backend = true;

      this.recall_data();
    });

    this.on_updated_work_data().subscribe((data: any) => {
      this.global_vars.updated_work_data_backend = true;

      this.recall_data();
    });

    this.on_updated_education_data().subscribe((data: any) => {
      this.global_vars.updated_education_data_backend = true;

      this.recall_data();
    });
    
    this.on_deleted_work_data().subscribe((data: any) => {
      this.global_vars.deleted_work_data_backend = true;

      this.recall_data();
    });

    this.on_deleted_education_data().subscribe((data: any) => {
      this.global_vars.deleted_education_data_backend = true;

      this.recall_data();
    });




    this.on_assessment_names().subscribe((data: any) => {
      this.global_vars.assessment_names = data;
    });


    this.on_assessment_saved_results().subscribe((data: any) => {
      this.sort_assessment_saved_results(data);

      this.global_vars.assessment_names_retrieved = true;
    });


    this.on_assessment_questions().subscribe((data: any) => {
      // console.log(data);
      this.global_vars.assessment_questions = data;

      this.global_vars.current_question = this.global_vars.assessment_questions["Q1"];
    });

    this.on_assessment_replies().subscribe((data: any) => {
      // console.log(data);

      this.sort_assessment_replies(data);
    });

    this.on_assessment_answers_reply().subscribe((data: any) => {
      console.log(data);
      this.global_vars.assessment_result = data;
    });
  }

  validate_input(data)
  {
    for (let property in data)
    {
      if (data[property] == "")
        return false;
    }
    
    return true;
  }

  register(data)
  {
    this.socket.emit("register", data);
  }

  on_register_reply()
  {
    return this.socket.fromEvent("register_reply");
  }

  login(data)
  {
    this.socket.emit("login", data);
  }

  on_login_reply()
  {
    return this.socket.fromEvent("login_reply");
  }


  dashboard_info()
  {
    this.socket.emit("dashboard_info", this.global_vars.user_data.iduser_candidate);
  }

  on_dashboard_info_reply()
  {
    return this.socket.fromEvent("dashboard_info_reply");
  }

  dashboard_reply_job(data)
  {
    this.global_vars.work_experience = data[0];

    this.global_vars.education = data[1];
  }


  update_data_and_go_dashboard()
  {
    this.socket.emit("update_data", {"user_data": this.global_vars.user_data, 
    "work_experience": this.global_vars.work_experience, 
    "education": this.global_vars.education, 
    "work_to_delete": this.global_vars.work_to_delete,
    "education_to_delete": this.global_vars.education_to_delete});

    this.routing_service.dashboardupdate_to_dashboard();
  }




  on_updated_user_data()
  {
    return this.socket.fromEvent("updated_user_data");
  }

  on_updated_work_data()
  {
    return this.socket.fromEvent("updated_work_data");
  }

  on_updated_education_data()
  {
    return this.socket.fromEvent("updated_education_data");
  }



  on_deleted_work_data()
  {
    return this.socket.fromEvent("deleted_work_data");
  }
  on_deleted_education_data()
  {
    return this.socket.fromEvent("deleted_education_data");
  }

  recall_data()
  {
    if (this.global_vars.updated_user_data_backend && this.global_vars.updated_education_data_backend && this.global_vars.updated_work_data_backend && this.global_vars.deleted_work_data_backend && this.global_vars.deleted_education_data_backend)
      this.dashboard_info();
  }


  get_assessment_names()
  {
    this.socket.emit("assessment_names", {iduser_candidate: this.global_vars.user_data.iduser_candidate});
  }

  on_assessment_names()
  {
    return this.socket.fromEvent("assessment_names_reply");
  }

  on_assessment_saved_results()
  {
    return this.socket.fromEvent("assessment_saved_results_reply");
  }

  sort_assessment_saved_results(data)
  {
    for(let i = 0; i < this.global_vars.assessment_names.length; i++)
    {
      this.global_vars.assessment_names[i]["to_disable"] = false;
    }

    for(let i = 0; i < data.length; i++)
    {
      // console.log(data[i]["Result"])
      this.global_vars.saved_assessment_results[data[i]["idAssessments"]] = data[i]["Result"].split("%");

      if (data[i]["idAssessments"] == "1")
      {
        for (let i = 0; i < this.global_vars.saved_assessment_results["1"].length; i++)
        {
          this.global_vars.saved_assessment_results["1"][i] += "%";
        }

        this.global_vars.saved_assessment_results["1"].pop()
      }
      else
      {
        // console.log(this.global_vars.saved_assessment_results["2"]);
        this.global_vars.saved_assessment_results["2"].push(this.global_vars.saved_assessment_results["2"][i].slice(4));
        this.global_vars.saved_assessment_results["2"][0] = this.global_vars.saved_assessment_results["2"][0].slice(0, 4);
      }

      this.global_vars.assessment_names[data[i]["idAssessments"] - 1]["to_disable"] = true;
    }
    // console.log(this.global_vars.assessment_names);

  }
  
  get_assessment_questions(id_assessment)
  {
    this.socket.emit("assessment_questions", {idAssessments: id_assessment});
  }

  on_assessment_questions()
  {
    return this.socket.fromEvent("assessment_questions_reply");
  }

  on_assessment_replies()
  {
    return this.socket.fromEvent("assessment_replies_reply");
  }


  sort_assessment_replies(data)
  {
    for(let i = 0; i < data.length; i++)
    {
      this.global_vars.assessment_replies["Q" + (i+1).toString()] = {Reply1: data[i].Reply1, Reply2: data[i].Reply2};
    }

    this.global_vars.current_reply1 = this.global_vars.assessment_replies["Q1"]["Reply1"];
    this.global_vars.current_reply2 = this.global_vars.assessment_replies["Q1"]["Reply2"];
  }

  send_result()
  {
    this.global_vars.assessment_answers["idAssessments"] = this.global_vars.assessment_questions["idAssessments"];

    this.global_vars.assessment_answers["iduser_candidate"] = this.global_vars.user_data.iduser_candidate;

    this.socket.emit("assessment_answers", this.global_vars.assessment_answers);
  }

  on_assessment_answers_reply()
  {
    return this.socket.fromEvent("assessment_answers_reply");
  }
}
