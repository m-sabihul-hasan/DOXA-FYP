import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class RoutingService {

  constructor(private router: Router) { }
  
  
  login_to_register()
  {
    this.router.navigate(['register']);
  }

  register_to_dashboard() 
  {
    this.router.navigate(['dashboard']);
  }

  login_to_dashboard()
  {
    this.router.navigate(['dashboard']);
  }

  dashboard_to_dashboardupdate() 
  {
    this.router.navigate(['dashboard-update']);
  }

  dashboardupdate_to_dashboard() 
  {
    this.router.navigate(['dashboard']);
  }

  assessment_to_take_assessment()
  {
    this.router.navigate(['take-assessment']);
  }

}
