import { Injectable } from '@angular/core';


export interface User_Data_Interface {
  iduser_candidate: Number;
  Name: String;
  Email: String;
  Password: String;
  Gender: String,
  Contact_Number: String;
  Job_Title: String;
  Position: String;
  About_Me: String;
  Facebook_Link: String;
  Twitter_Link: String;
  Instagram_Link: String;
  Linkedin_Link: String;
}

export interface Work_Experience_Interface {
  idwork_experience: Number;
  Designation: String;
  Company: String;
  Starting_Year: String;
  Ending_Year: String;
  Location: String;
  Job_Responsibilities: String;
  user_candidate_fk: Number;
}

export interface Education_Interface {
  ideducation: Number;
  Title: String;
  Degree: String;
  Institute: String;
  Location: String;
  Starting_Year: String;
  Ending_Year: String;
  About: String;
  user_candidate_fk: Number;
}

@Injectable({
  providedIn: 'root'
})



export class GlobalVariablesService {

  error = "";

  hide_error = true;

  user_data: User_Data_Interface;

  work_experience: Array<Work_Experience_Interface>;

  education: Array<Education_Interface>;

  user_data_retrieved = false;

  work_to_delete = [];

  education_to_delete = [];



  updated_user_data_backend = true;
  updated_education_data_backend = true;
  updated_work_data_backend = true;
  deleted_education_data_backend = true;
  deleted_work_data_backend = true;




  assessment_names = [];

  assessment_questions = [];
  assessment_replies = {};

  assessment_names_retrieved = false;

  saved_assessment_results = {};

  assessment_answers = {};

  current_assessment_id = "";


  current_question = "";
  current_question_number = 1;

  current_reply1 = "";
  current_reply2 = "";

  assessment_result = ["Calculating..."];

  constructor() { }
}
